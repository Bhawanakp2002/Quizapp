//quiz questions
const questions=[
    {
        'que':" HTML stands for ",
        'a':"HighText Machine Language",
        'b':"HyperText and links Markup Language",
        'c': "HyperText Markup Language",
        'd':"None of these",
        'correct':'c'
    },
    
    {
        'que':"Which of these elements in HTML can be used for making a text bold?",
        'a':"<a>",
        'b':"<pre>",
        'c': "<br>",
        'd':"<b>",
        'correct':'d'
    },
    {
        'que':"Which tag do we use to define the options present in the drop-down selection lists?",
        'a':" <list>",
        'b':" <select>",
        'c': "<option>",
        'd':" <dropdown>",
        'correct':'c'
    },
    {
        'que':"What does CSS stand for?",
        'a':"Hypertext Markup Language",
        'b':"Cascading Style sheet",
        'c': "Helicopter terminal",
        'd':"Json Object Notation",
        'correct':'b'
    },
    {
        'que':" Which HTML tag do we use to display text along with a scrolling effect?",
        'a':"<div>",
        'b':"<scroll>",
        'c': "<marquee>",
        'd':"None of the above",
        'correct':'c'
    },
    {
        'que':"In HTML, we use the <hr> tag for ___________.",
        'a':"horizontal ruler",
        'b':" new line",
        'c': " new paragraph",
        'd':"vertical ruler",
        'correct':'a'
    },
    {
        'que':"In HTML, the tags are __________.",
        'a':" in upper case",
        'b':"case-sensitive",
        'c': " in lowercase",
        'd':"not case sensitive",
        'correct':'d'
    },
    {
        'que':"Which tag is used in HTML5 for the initialization of the document type?",
        'a':"<Doctype HTML>",
        'b':"<!DOCTYPE html>",
        'c': "<Doctype>",
        'd':"<\Doctype html>",
        'correct':'b'
    },
    {
        'que':"What is the correct way in which we can start an ordered list that has the numeric value count of 5?",
        'a':"<ol type = “1” start = “5”>",
        'b':"<ol type = “1” num = “5”>",
        'c': "<ol type = “1” begin = “5”>",
        'd':" <ol type = “1” initial = “5”>",
        'correct':'a'
    },
    {
        'que':"Which one is the HTML document’s root tag?",
        'a':"<head>",
        'b':"<body>",
        'c': "<title>",
        'd':"<html>",
        'correct':'d'
    },
    {
        'que':" How does the <bdo> element work?",
        'a':"changes direction of the ltr text",
        'b':"stops writing in current direction of text",
        'c': "override the direction of the rtl text",
        'd':"override the text direction",
        'correct':'d'
    },
    {
        'que':"What attribute do we use for data binding?",
        'a':"datasrc",
        'b':"mayscript",
        'c': "name",
        'd':"datafld",
        'correct':'a'
    },
    {
        'que':"Which of these entities is not defined in the XML?",
        'a':"apos",
        'b':"quot",
        'c': "copy",
        'd':"gt",
        'correct':'c'
    },
    {
        'que':"Which of these classes helps make a text stand out?",
        'a':".small",
        'b':" .lead",
        'c': " .text-center",
        'd':" .text-left",
        'correct':'b'
    },
    {
        'que':" Which of these tags helps in the creation of a drop-down box or a combo box?",
        'a':"<input type = “dropdown”>",
        'b':" <list>",
        'c': "<ul>",
        'd':"<select>",
        'correct':'d'
    },
    {
        'que':"In HTML, the correct way of commenting out something would be using:",
        'a':"## and #",
        'b':"<!– and –>",
        'c': "</– and -/->",
        'd':"<!– and -!>",
        'correct':'b'
    },
    {
        'que':"The non-ASCII characters would be replaced with ________ by the process of URL encoding.",
        'a':"“+”",
        'b':"“%”",
        'c': " “&”",
        'd':" “*”",
        'correct':'b'
    },
    {
        'que':"Which of these doesn’t support the MP3 format?",
        'a':"Opera",
        'b':"Safari",
        'c': "Chrome",
        'd':"Firefox",
        'correct':'a'
    },
    {
        'que':"The correct sequence of HTML tags for starting a webpage is -",
        'a':"Head, Title, HTML, body",
        'b':"HTML, Body, Title, Head",
        'c': "HTML, Head, Title, Body",
        'd':"HTML, Head, Title, Body",
        'correct':'d'
    },
    {
        'que':"Which of the following tag is used for inserting the largest heading in HTML?",
        'a':"<h3>",
        'b':"<h1>",
        'c': "<h5>",
        'd':"<h6>",
        'correct':'b'
    },
    {
        'que':"How to create an unordered list (a list with the list items in bullets) in HTML?",
        'a':"<ul>",
        'b':"<ol>",
        'c': "<li>",
        'd':"<i>",
        'correct':'a'
    },
    {
        'que':"Who is the father of HTML?",
        'a':"Rasmus Lerdorf",
        'b':"Tim Berners-Lee",
        'c': " Brendan Eich",
        'd':"Sergey Brin",
        'correct':'b'
    },
    {
        'que':"Which of the following is used to read an HTML page and render it?",
        'a':"Web server",
        'b':"Web network",
        'c': "Web browser",
        'd':"Web matrix",
        'correct':'c'
    },
    {
        'que':"What is DOM in HTML?",
        'a':"Language dependent application programming",
        'b':"Hierarchy of objects in ASP.NET",
        'c': "Application programming interface",
        'd':"Convention for representing and interacting with objects in html documents",
        'correct':'d'
    },
    {
        'que':"In which part of the HTML metadata is contained?",
        'a':"head tag",
        'b':"title tag",
        'c': "html tag",
        'd':"body tag",
        'correct':'a'
    },
    {
        'que':"Which element is used to get highlighted text in HTML5?",
        'a':"<u>",
        'b':"<mark>",
        'c': "<highlight>",
        'd':"<b>",
        'correct':'b'
    },      
]
// assign program
let index = 0;
let correct = 0,
    incorrect = 0,
    total = questions.length;
let quesBox = document.getElementById("quesBox");
let optionInputs = document.querySelectorAll('.options');
const loadQuestion = () => {
    //quiz end
    if (total === index) {
        return quizEnd()
    }
    reset()
    const data = questions[index];
    quesBox.innerText = `${index + 1}) ${data.que}`;
    //codem  for options
    optionInputs[0].nextElementSibling.innerText=data.a;
    optionInputs[1].nextElementSibling.innerText=data.b;
    optionInputs[2].nextElementSibling.innerText=data.c;
    optionInputs[3].nextElementSibling.innerText=data.d;
};
document.querySelector("#submit").addEventListener(
    "click",
    function() {
        const data = questions[index]
        const ans = getAnswer()
        //first select the option after proceed to next
        if (!ans) {
            alert("Please select an option before proceeding.");
            return; 
        }
        //corrrect condition
        if (ans === data.correct) {
            correct++;
        } else {
            //incorrect condition
            incorrect++;
        }
        index++;
        loadQuestion()
    }
)
//Get answer
const getAnswer = () => {
    let ans;
    optionInputs.forEach(
        (inputEl) => {
            if (inputEl.checked) {
                ans = inputEl.value;
            }
        }
    )
    return ans;
}
const reset = () => {
    optionInputs.forEach(
        (inputEl) => {
            inputEl.checked = false;
        }
    )
}

const quizEnd = () => {
    document.getElementsByClassName("rounded-box")[0].innerHTML = `
        <div class="row">
            <h3 class="w-100">Your score is  ${correct} / ${total} </h3>
        </div>
    `
}
//initial call
loadQuestion(index);